package com.example.anonmes.userdata;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.anonmes.ChatActivity;
import com.example.anonmes.LoginActivity;
import com.example.anonmes.MainActivity;
import com.example.anonmes.R;
import com.example.anonmes.TunnelSettingsActivity;

public class EntryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_entry);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.act_entry), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    public void clickTunnelSettings(View view){
        Intent intent = new Intent(EntryActivity.this, TunnelSettingsActivity.class);
        startActivity(intent);
    }
    public void clickGoToChats(View view){
        Intent intent = new Intent(EntryActivity.this, ChatActivity.class);
        startActivity(intent);
    }
}
