package com.example.anonmes;


import android.util.Base64;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class CryptManager{


    PublicKey publicKey;
    PrivateKey privateKey;


    public CryptManager(String privkey, String pubkey) {
        try {
            privateKey = stringToPrivateKey(privkey);
            publicKey = stringToPublicKey(pubkey);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }


    }


    public String encrypt(Message message){

        return null;
    }


    private PrivateKey stringToPrivateKey(String keyStr) throws Exception {
        byte[] keyBytes = Base64.decode(keyStr, Base64.DEFAULT);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(spec);
    }


    private PublicKey stringToPublicKey(String keyStr) throws Exception {
        byte[] keyBytes = Base64.decode(keyStr, Base64.DEFAULT);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(spec);
    }
}
