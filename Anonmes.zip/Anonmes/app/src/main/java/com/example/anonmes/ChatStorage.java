package com.example.anonmes;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ChatStorage {
    private static final String PREFS_NAME = "app_prefs";
    private static final String KEY_CHATS = "chats_list";
    private SharedPreferences prefs;
    private Gson gson;

    public ChatStorage(Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.gson = new Gson();
    }


    public void saveChats(List<ChatModel> chatList) {
        String json = gson.toJson(chatList);
        prefs.edit().putString(KEY_CHATS, json).apply();
    }


    public List<ChatModel> loadChats() {
        String json = prefs.getString(KEY_CHATS, null);
        if (json == null) return new ArrayList<>();

        Type type = new TypeToken<List<ChatModel>>() {}.getType();
        return gson.fromJson(json, type);
    }
}
