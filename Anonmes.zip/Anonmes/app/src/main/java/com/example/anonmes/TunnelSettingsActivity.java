package com.example.anonmes;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class TunnelSettingsActivity extends AppCompatActivity {
    TextView tv_params;
    EditText et_proxy,et_port,et_in,et_out;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.fragment_settings);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.tunnel_act), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        et_in = findViewById(R.id.edit_in_tunnel);
        et_out = findViewById(R.id.edit_out_tunnel);
        et_port = findViewById(R.id.edit_port);
        et_proxy = findViewById(R.id.edit_proxy);
        tv_params = findViewById(R.id.tv_current_params);
        //Proxy: 127.0.0.1 | Port: 4272\nIn: 3 | Out: 3
        SharedPreferences proxySettingPreferences = this.getSharedPreferences("tunnel_settings",Context.MODE_PRIVATE);
        String proxy = proxySettingPreferences.getString("proxy",null);
        String port;
        String inboundLength,outboundLength;
        if (proxy!=null){
            port = proxySettingPreferences.getString("port","");
            inboundLength = proxySettingPreferences.getString("in","");
            outboundLength = proxySettingPreferences.getString("out","");
            String text = "Proxy: "+proxy+" | Port: "+port+"\nIn: "+inboundLength+" | Out: "+outboundLength;
            tv_params.setText(text);
        }

    }

    public void saveParams(View view){
        String proxy = et_proxy.getText().toString();
        String port = et_port.getText().toString();
        String in = et_in.getText().toString();
        String out = et_out.getText().toString();

        try {
            int res = Integer.parseInt(proxy.replace(".",""));
            int r1=Integer.parseInt(port);
            int r2=Integer.parseInt(in);
            int r3=Integer.parseInt(out);

            if (r3>10 || r2>10 || r3<1 || r2<1){
                Toast.makeText(this, "Длина туннелей должна быть от 1 до 10", Toast.LENGTH_SHORT).show();
                throw new RuntimeException();
            }


            SharedPreferences proxySettingPreferences = this.getSharedPreferences("tunnel_settings",Context.MODE_PRIVATE);
            proxySettingPreferences.edit().putString("proxy",proxy).apply();
            proxySettingPreferences.edit().putString("port",port).apply();
            proxySettingPreferences.edit().putString("in",in).apply();
            proxySettingPreferences.edit().putString("out",out).apply();

            String text = "Proxy: "+proxy+" | Port: "+port+"\nIn: "+in+" | Out: "+out;
            tv_params.setText(text);
            Toast.makeText(this, "Значения сохранены", Toast.LENGTH_SHORT).show();

        }catch (Exception e){
            Toast.makeText(this, "Заполните поля корректно", Toast.LENGTH_SHORT).show();
        }


    }
    public void setDefault(View view){
        tv_params.setText("Proxy: 127.0.0.1 | Port: 4272\nIn: 3 | Out: 3");
        SharedPreferences proxySettingPreferences = this.getSharedPreferences("tunnel_settings",Context.MODE_PRIVATE);
        proxySettingPreferences.edit().putString("proxy","127.0.0.1").apply();
        proxySettingPreferences.edit().putString("port","4272").apply();
        proxySettingPreferences.edit().putString("in","3").apply();
        proxySettingPreferences.edit().putString("out","3").apply();
        Toast.makeText(this, "Восстановлены значения по умолчанию", Toast.LENGTH_SHORT).show();
    }
    public void buttonReturn(View view){
        finish();
    }

    private void saveParamsToFile(String proxy, String port, String in, String out){

    }


}
