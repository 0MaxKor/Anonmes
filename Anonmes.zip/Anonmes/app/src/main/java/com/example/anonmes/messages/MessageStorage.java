package com.example.anonmes.messages;

public class MessageStorage {
}
