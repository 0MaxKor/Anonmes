package com.example.anonmes;

public class MessageModel {
    public String text;
    public boolean isMine; // true - справа (я), false - слева (собеседник)
    long date=0;

    public MessageModel(String text, boolean isMine) {
        this.text = text;
        this.isMine = isMine;
    }
    public void setDate(long date){
        this.date = date;
    }
}
