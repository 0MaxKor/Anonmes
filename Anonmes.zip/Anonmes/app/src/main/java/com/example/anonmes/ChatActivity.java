package com.example.anonmes;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.anonmes.crypt.KeyLocalStorage;
import com.example.anonmes.crypt.MessageCrypt;
import com.example.anonmes.crypt.ServerHandshake;
import com.example.anonmes.messages.LogRegMessage;
import com.example.anonmes.messages.MessageDao;
import com.example.anonmes.messages.MyDataLocal;
import com.example.anonmes.messages.NetworkMessage;
import com.example.anonmes.messages.NetworkMessageTypes;
import com.example.anonmes.messages.UserDeviceMessage;
import com.example.anonmes.messages.UserMessage;
import com.example.anonmes.room.AppDatabase;
import com.example.anonmes.userdata.UserData;
import com.example.anonmes.userdata.UserDataDao;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;


public class ChatActivity extends AppCompatActivity {
    private ChatAdapter adapter;
    //Socket socket;
    UserDataDao tb_users;
    MessageDao tb_messages;
    private MessageAdapter messageAdapter;
    private RecyclerView rvMessages;
    //ServerHandshake handshake;

    MessageStorage messageStorage;
    List<ChatModel> chatModels;
    List<MessageModel> messageModels;
    String curChatId = "";
    //SocketManager socketManager;
    String MY_ID;
    MessageCrypt messageCrypt;
    KeyLocalStorage keyLocalStorage;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.fragment_chats);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.chats_act), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        AppDatabase database = AppDatabase.getInstance(this);
        tb_users = database.userDao();
        tb_messages = database.messageDao();
        SharedPreferences proxySettingPreferences = this.getSharedPreferences("tunnel_settings", Context.MODE_PRIVATE);
        String proxy = proxySettingPreferences.getString("proxy", null);
        String port = proxySettingPreferences.getString("port", null);


        //socketManager = new SocketManager();


        ;

//        socketManager.connect("10.0.2.2", 12345, text -> {
//            runOnUiThread(() -> {
//
//                Message msg = new Gson().fromJson(text, Message.class);
//                DecryptedMessage decryptedMessage = messageCrypt.decryptMessage(msg);
//                messageModels.add(new MessageModel(msg.content, false));
//                messageAdapter.notifyItemInserted(messageModels.size() - 1);
//            });
//        });
        messageModels = new ArrayList<>();


        messageStorage = new MessageStorage(this);
        chatModels = new ArrayList<>();

        MyDataLocal dataLocal = new MyDataLocal(this);
        keyLocalStorage = new KeyLocalStorage();
        messageCrypt = new MessageCrypt(keyLocalStorage, this);


        ImageButton btnAddChat = findViewById(R.id.btn_add_contact);

        btnAddChat.setOnClickListener(v -> {
            showAddChatDialog();
        });


        RecyclerView recyclerView = findViewById(R.id.rv_chats);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        TextView chatTitle = findViewById(R.id.chat_title);


        ChatAdapter.OnChatClickListener chatClickListener = new ChatAdapter.OnChatClickListener() {
            @Override
            public void onChatClick(ChatModel chat) {
                chatTitle.setText("Чат с: " + chat.username);
                curChatId = chat.id;

                // 1. Удаляем старые наблюдения (чтобы сообщения из разных чатов не перемешивались)
                // Если вы используете LiveData внутри клика, это важно.
                tb_messages.getMessagesForUser(chat.username).observe(ChatActivity.this, messages -> {

                    // 2. Очищаем старые модели в адаптере
                    messageModels.clear();

                    if (messages != null) {
                        for (UserDeviceMessage m : messages) {
                            // Преобразуем UserDeviceMessage (Room) в MessageModel (UI)
                            // Здесь true/false зависит от того, кто отправитель (вы или собеседник)
                            messageModels.add(new MessageModel(m.getContent(), m.isMine()));
                        }
                    }

                    // 3. Уведомляем адаптер сообщений об изменениях
                    messageAdapter.notifyDataSetChanged();

                    // Прокручиваем в конец списка
                    if (messageModels.size() > 0) {
                        rvMessages.scrollToPosition(messageModels.size() - 1);
                    }
                });
            }
        };

// 3. Установка адаптера (список chatModels наполнится через observe в onCreate)
        adapter = new ChatAdapter(chatModels, chatClickListener);
        recyclerView.setAdapter(adapter);

        tb_users.getAllUserdata().observe(this, users -> {
            if (users != null) {
                chatModels.clear();
                for (UserData user : users) {
                    // Создаем ChatModel с тремя параметрами: id, name, username
                    chatModels.add(new ChatModel(
                            String.valueOf(user.getId()),
                            user.getFirstname(),
                            user.getUniqueName()
                    ));
                }
                // Уведомляем адаптер
                adapter.notifyDataSetChanged();
            }
        });


        rvMessages = findViewById(R.id.rv_messages);
        messageAdapter = new MessageAdapter(messageModels);
        rvMessages.setLayoutManager(new LinearLayoutManager(this));
        rvMessages.setAdapter(messageAdapter);
        EditText editMessage = findViewById(R.id.edit_message);
        ImageButton btnSend = findViewById(R.id.btn_send);
        btnSend.setOnClickListener(v -> {
            String text = editMessage.getText().toString().trim();
            if (!text.isEmpty() && !curChatId.isEmpty()) {

                String currentUserName = chatTitle.getText().toString().replace("Чат с: ", "");

                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Socket socket = null;
                        try {
                            Log.i("AESSSSSSSS", "SENDING - 1 ");
                            socket = new Socket(proxy, Integer.parseInt(port));
                            socket.setSoTimeout(20000);
                            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
                            ServerHandshake handshake = new ServerHandshake(printWriter, br, ChatActivity.this);
                            Gson gson = new Gson();

                            String userPubkey = tb_users.getPubkeyForUser(currentUserName);
                            Log.i("AESSSSSSSS", "SENDING - 2 ");
                            if (userPubkey.isEmpty()) {
                                NetworkMessage queryPubKey = new NetworkMessage(NetworkMessageTypes.TYPE_QUERY_PUBKEY.getVal(), 0, 0, Base64.encodeToString(messageCrypt.encryptDataAES(currentUserName.getBytes(), handshake.getAes(), Constants.INITIAL_IV.getVal()), Base64.NO_WRAP), 0, 0, "");
                                printWriter.println(gson.toJson(queryPubKey));
                                printWriter.flush();
                                String reply = new String(messageCrypt.decryptDataAES(Base64.decode(br.readLine(), Base64.NO_WRAP), handshake.getAes(), Constants.INITIAL_IV.getVal()));
                                Log.i("AESSSSSSSS", "New pubkey got: " + reply);
                                tb_users.updateKeyByName(currentUserName, reply);
                                userPubkey = reply;
                            }

                            Log.i("AESSSSSSSS", "Begin to send...");
                            String tempAES = messageCrypt.generateAESKey();
                            String encryptedText = Base64.encodeToString(messageCrypt.encryptDataAES(text.getBytes(), tempAES, Constants.INITIAL_IV.getVal()), Base64.NO_WRAP);
                            String encryptedAes = Base64.encodeToString(messageCrypt.encryptDataRSA(tempAES.getBytes(), MessageCrypt.getPublicKeyFromString(userPubkey)), Base64.NO_WRAP);
                            UserMessage sendm = new UserMessage(encryptedText, dataLocal.getUsername(), currentUserName, 0, encryptedAes);
                            Log.i("AESSSSS", "SENDMESSAGE: " + sendm.toString());
                            byte[] encrypted = messageCrypt.encryptDataAES(gson.toJson(sendm).getBytes(), handshake.getAes(), Constants.INITIAL_IV.getVal());
                            NetworkMessage sendMessage = new NetworkMessage(NetworkMessageTypes.TYPE_SEND_MESSAGE.getVal(), 0, 0, Base64.encodeToString(encrypted, Base64.NO_WRAP), 0, 0, "");
                            printWriter.println(gson.toJson(sendMessage));
                            printWriter.flush();
                            Log.i("AESSSSSSSS", "Sent textmessage: ");
                            String reply = br.readLine();
                            Log.i("AESSSSSSSS", "The reply sendmes: " + reply);
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (reply.equals("0")) {
                                        Toast.makeText(ChatActivity.this, "Сообщение отправлено", Toast.LENGTH_SHORT).show();
                                        UserDeviceMessage roomMsg = new UserDeviceMessage(
                                                currentUserName,
                                                text,
                                                System.currentTimeMillis(),
                                                true
                                        );

                                        // 3. Сохраняем в базу в фоновом потоке
                                        new Thread(() -> {
                                            tb_messages.insert(roomMsg);

                                            // Здесь можно отправить сообщение по сокету, если нужно
                                            // socketManager.sendMessage(...);
                                        }).start();
                                    } else {
                                        Toast.makeText(ChatActivity.this, "Ошибка отправки", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                            socket.close();
                        }catch (SocketTimeoutException e) {
                            try {
                                socket.close(); // Закрываем вручную
                            } catch (IOException ex) {

                            }
                        } catch (Exception e) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(ChatActivity.this, "Ошибка отправки", Toast.LENGTH_SHORT).show();
                                }
                            });

                            System.err.println("AESSSSS Error in sendmessage" + e.getMessage());
                        }

                    }
                }).start();


                // 2. Создаем сущность для базы данных Room


                // 4. Очищаем поле ввода
                editMessage.setText("");

            } else if (curChatId.isEmpty()) {
                Toast.makeText(this, "Сначала выберите чат!", Toast.LENGTH_SHORT).show();
            }
        });
        Thread getMessagesThread = new Thread(new Runnable() {
            @Override
            public void run() {

                while (true) {
                    Socket socket = null;
                    try {
                        Log.i("AESSSSSSSS", "gettingMesgQuery");
                        socket = new Socket(proxy, Integer.parseInt(port));
                        BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
                        ServerHandshake handshake = new ServerHandshake(printWriter, br, ChatActivity.this);
                        Gson gson = new Gson();
                        Log.i("AESSSSSSS", dataLocal.getUsername());
                        LogRegMessage logRegMessage = new LogRegMessage(dataLocal.getUsername(), "", "");

                        logRegMessage.setSha256Passwd(dataLocal.getPasswdHash());
                        byte[] encrypted = messageCrypt.encryptDataAES(gson.toJson(logRegMessage).getBytes(), handshake.getAes(), Constants.INITIAL_IV.getVal());

                        NetworkMessage networkMessage = new NetworkMessage(NetworkMessageTypes.TYPE_QUERY_MESSAGES.getVal(), 0, 0, Base64.encodeToString(encrypted, Base64.NO_WRAP), 0, 0, "");
                        printWriter.println(gson.toJson(networkMessage));
                        printWriter.flush();
                        Log.i("AESSSSSSSS", "Sent query");
                        String res = null;
                        try {
                            res = br.readLine();
                            if (!res.equals("0")) {
                                Type listType = new TypeToken<ArrayList<UserMessage>>() {
                                }.getType();

                                ArrayList<UserMessage> messages = gson.fromJson(new String(messageCrypt.decryptDataAES(Base64.decode(res.getBytes(), Base64.NO_WRAP), handshake.getAes(), Constants.INITIAL_IV.getVal())), listType);
                                for (UserMessage m : messages) {
                                    Log.i("AESSSSSSSS", m.toString());
                                }
                                handleNewMessages(messages);
                            }
                        } catch (Exception e) {
                            Log.e("AESSSSS", e.getMessage());
                        }

                        Log.i("AESSSSSSSS", "Query mes result: " + res);


                        socket.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }

                    try {
                        Thread.sleep(20000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }


            }
        });
        getMessagesThread.start();


    }

    private void fakeResponse(String request) {
        rvMessages.postDelayed(() -> {
            messageModels.add(new MessageModel("Ты сказал: " + request, false));
            messageAdapter.notifyItemInserted(messageModels.size() - 1);
            rvMessages.scrollToPosition(messageModels.size() - 1);
            messageStorage.saveMessages(messageModels, curChatId);
        }, 1000);
    }


    String[] generateKeyPair() {
        String[] res = new String[2];
        KeyPairGenerator kpg = null;
        try {
            kpg = KeyPairGenerator.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        KeyPair keyPair = kpg.generateKeyPair();
        res[0] = Base64.encodeToString(keyPair.getPrivate().getEncoded(), Base64.DEFAULT);
        res[1] = Base64.encodeToString(keyPair.getPublic().getEncoded(), Base64.DEFAULT);
        return res;
    }

    void upgradeKeyPair() {
        var prefs = getSharedPreferences("user_keys", Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = prefs.edit();
        String[] keypair = generateKeyPair();
        editor.putString("priv_key", keypair[0]);
        editor.putString("pub_key", keypair[1]);
        editor.apply();

    }

    String getPrivateKey() {

        var prefs = getSharedPreferences("user_keys", Context.MODE_PRIVATE);
        String privateKey = prefs.getString("priv_key", "no");
        if (privateKey.equals("no")) {

            SharedPreferences.Editor editor = prefs.edit();
            String[] keypair = generateKeyPair();
            editor.putString("priv_key", keypair[0]);
            editor.putString("pub_key", keypair[1]);
            editor.apply();
            return keypair[0];
        } else {
            return privateKey;
        }

    }

    String getPublicKey() {

        var prefs = getSharedPreferences("user_keys", Context.MODE_PRIVATE);
        String publicKey = prefs.getString("pub_key", "no");
        if (publicKey.equals("no")) {

            SharedPreferences.Editor editor = prefs.edit();
            String[] keypair = generateKeyPair();
            editor.putString("priv_key", keypair[0]);
            editor.putString("pub_key", keypair[1]);
            editor.apply();
            return keypair[1];
        } else {
            return publicKey;
        }

    }

    private void showAddChatDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Новый чат");

        final EditText input = new EditText(this);
        input.setHint("Введите имя контакта");
        builder.setView(input);

        builder.setPositiveButton("Добавить", (dialog, which) -> {
            String name = input.getText().toString().trim();
            if (!name.isEmpty()) {


                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        Socket socket=null;
                        try {
                            SharedPreferences proxySettingPreferences = ChatActivity.this.getSharedPreferences("tunnel_settings", Context.MODE_PRIVATE);
                            String proxy = proxySettingPreferences.getString("proxy", null);
                            String port = proxySettingPreferences.getString("port", null);
                            socket = new Socket(proxy, Integer.parseInt(port));
                            socket.setSoTimeout(20000);
                            BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
                            ServerHandshake handshake = new ServerHandshake(printWriter, br, ChatActivity.this);
                            Gson gson = new Gson();


                            if (!tb_users.isUserExists(name)) {
                                NetworkMessage queryPubKey = new NetworkMessage(NetworkMessageTypes.TYPE_QUERY_PUBKEY.getVal(), 0, 0, Base64.encodeToString(messageCrypt.encryptDataAES(name.getBytes(), handshake.getAes(), Constants.INITIAL_IV.getVal()), Base64.NO_WRAP), 0, 0, "");
                                printWriter.println(gson.toJson(queryPubKey));
                                printWriter.flush();
                                String reply = new String(messageCrypt.decryptDataAES(Base64.decode(br.readLine(), Base64.NO_WRAP), handshake.getAes(), Constants.INITIAL_IV.getVal()));
                                Log.i("AESSSSSSSS", "Pubkey query (add user): " + reply);
                                if (reply.equals("" + Statuses.ERR_NO_SUCH_USER.getCode()) || reply.length() < 10) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(ChatActivity.this, "Ошибка при добавлении", Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                } else {
                                    UserData newUser = new UserData(
                                            (int) (System.currentTimeMillis() / 1000),
                                            name,
                                            name,
                                            "" // pubKey пока пустой
                                    );

                                    // 2. Вставляем в базу данных в фоновом потоке
                                    new Thread(() -> {
                                        tb_users.insert(newUser);
                                    }).start();
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            Toast.makeText(ChatActivity.this, "Пользователь добавлен", Toast.LENGTH_SHORT).show();
                                        }
                                    });

                                }
                            } else {
                                runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(ChatActivity.this, "Пользователь с таким именем уже добавлен", Toast.LENGTH_SHORT).show();

                                    }
                                });
                            }
                            socket.close();
                        }catch (SocketTimeoutException e) {
                            try {
                                socket.close(); // Закрываем вручную
                            } catch (IOException ex) {

                            }
                        }catch (Exception e) {
                            runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(ChatActivity.this, "Ошибка при добавлении", Toast.LENGTH_SHORT).show();
                                }
                            });

                            System.err.println("AESSSSSSSS" + e.getMessage());
                        }

                    }
                }).start();


                // 1. Создаем объект UserData для Room
                // Используем System.currentTimeMillis() как временный ID,
                // а name — и как имя, и как username для простоты


                // ВАЖНО: adapter.addChat и chatStorage БОЛЬШЕ НЕ НУЖНЫ.
                // LiveData в onCreate сама обновит список.
            }
        });

        builder.setNegativeButton("Отмена", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    void handleNewMessages(ArrayList<UserMessage> messages) {
        List<UserDeviceMessage> messagesLocal = tb_messages.getAllMessageSync();
        Log.i("AESSSSSSS", "Handle messages ");
        messages.sort(new Comparator<UserMessage>() {
            @Override
            public int compare(UserMessage o1, UserMessage o2) {
                int comp = o1.getFromId().compareTo(o2.getFromId());
                if (comp == 0) {
                    if (o1.getTime() < o2.getTime()) {
                        return -1;
                    } else if (o1.getTime() == o2.getTime()) {
                        return 0;
                    } else return 1;
                } else {
                    return comp;
                }

            }
        });
        String last_username = "";
        for (int i = 0; i < messages.size(); i++) {
            var d = messages.get(i);

            d.setTime(i);
            messages.set(i, d);
            if (!d.getFromId().equals(last_username)) {
                if (!tb_users.isUserExists(d.getFromId())) {
                    tb_users.insert(new UserData(21, d.getFromId(), d.getFromId(), ""));
                }

            }
            String textDecrypted = null;
            try {
                String aesKeyDecrypted = new String(messageCrypt.decryptDataRSA(Base64.decode(d.getEncryptedAes().getBytes(), Base64.NO_WRAP)));
                textDecrypted = new String(messageCrypt.decryptDataAES(Base64.decode(d.getContent(), Base64.NO_WRAP), aesKeyDecrypted, Constants.INITIAL_IV.getVal()));
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            tb_messages.insert(new UserDeviceMessage(d.getFromId(), textDecrypted, System.currentTimeMillis() + d.getTime(), false));


            last_username = d.getFromId();
        }

        for (int i = 0; i < messagesLocal.size(); i++) {
            System.out.println("AESSSSSSS" + messagesLocal.get(i).toString());
        }
    }

    public void buttonInChatsReturn(View v) {
        finish();
    }



}