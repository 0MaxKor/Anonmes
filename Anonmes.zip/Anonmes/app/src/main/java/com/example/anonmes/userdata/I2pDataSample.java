package com.example.anonmes.userdata;

public class I2pDataSample {
    String data;
    String host;
    String port;
    String in;
    String out;
    String i2pServer;
    String i2pServerPort;

    public I2pDataSample(String host, String port, String in, String out, String i2pServer, String i2pServerPort) {
        this.host = host;
        this.port = port;
        this.in = in;
        this.out = out;
        this.i2pServer = i2pServer;
        this.i2pServerPort = i2pServerPort;
        data = "[ANONMES-CONNECTION]\n" +
                "type=client\n" +
                "address="+host+"\n" +
                "port="+port+"\n" +
                "destination="+i2pServer+"\n" +
                "destinationport="+i2pServerPort+"\n" +
                "inbound.length="+in+"\n" +
                "outbound.length="+out;
    }

    public String getData() {
        return data;
    }
}
