package com.example.anonmes.messages;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "messages")
public class UserDeviceMessage {
    @PrimaryKey(autoGenerate = true)
    int id;
    boolean mine;
    String userName;
    String content;
    long timestamp;



    public UserDeviceMessage(String userName, String content, long timestamp, boolean mine) {
        this.userName = userName;
        this.content = content;
        this.timestamp = timestamp;
        this.mine = mine;
    }
    public boolean isMine() {
        return mine;
    }

    public void setMine(boolean mine) {
        this.mine = mine;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }



    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "UserDeviceMessage{" +
                "id=" + id +
                ", userName='" + userName + '\'' +
                ", content='" + content + '\'' +
                ", timestamp=" + timestamp +
                '}';
    }
}
