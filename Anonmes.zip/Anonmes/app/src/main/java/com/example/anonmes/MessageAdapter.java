package com.example.anonmes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MessageAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<MessageModel> messageList;

    public MessageAdapter(List<MessageModel> messageList) {
        this.messageList = (messageList != null) ? messageList : new ArrayList<>();
    }

    @Override
    public int getItemViewType(int position) {

        return messageList.get(position).isMine ? 1 : 0;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == 1) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_sent, parent, false);
            return new SentViewHolder(v);
        } else {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_message_received, parent, false);
            return new ReceivedViewHolder(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        String text = messageList.get(position).text;
        if (holder instanceof SentViewHolder) {
            ((SentViewHolder) holder).messageText.setText(text);
        } else {
            ((ReceivedViewHolder) holder).messageText.setText(text);
        }
    }

    @Override
    public int getItemCount() { return messageList.size(); }


    static class SentViewHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        SentViewHolder(View v) { super(v); messageText = v.findViewById(R.id.message_text); }
    }

    static class ReceivedViewHolder extends RecyclerView.ViewHolder {
        TextView messageText;
        ReceivedViewHolder(View v) { super(v); messageText = v.findViewById(R.id.message_text); }
    }
}
