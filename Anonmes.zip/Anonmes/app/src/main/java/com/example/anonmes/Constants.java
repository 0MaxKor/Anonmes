package com.example.anonmes;

public enum Constants {
    INITIAL_IV(new byte[]{1,2,3,4,1,2,3,8,0,4,5,6});
    byte[] val;
    private Constants(byte[] v){
        val = v;
    }
    public byte[]getVal(){
        return val;
    }
}
