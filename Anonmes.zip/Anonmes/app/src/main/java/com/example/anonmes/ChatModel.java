package com.example.anonmes;

public class ChatModel {
    public String id;
    public String name;
    public String username;

    public ChatModel(String id, String name,String username) {
        this.id = id;
        this.name = name;
        this.username = username;
    }
}
