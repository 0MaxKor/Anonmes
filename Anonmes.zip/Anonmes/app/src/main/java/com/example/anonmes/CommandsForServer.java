package com.example.anonmes;

public enum CommandsForServer {


    COMMAND_SEND_MESSAGE("/sm"),
    COMMAND_RECEIVE_MESSAGES("/rm");







    private CommandsForServer(String command){
        this.command = command;
    }
    public String getCommand(){
        return command;
    }
    private String command;
}
