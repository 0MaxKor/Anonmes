package com.example.anonmes;

import java.util.Arrays;

public class Message {
    public int fromId;
    public int toId;
    public String command;
    public String type;
    public String content;


    public Message() {}

    public Message(int fromId, int toId, String command, String type, String content) {
        this.fromId = fromId;
        this.toId = toId;
        this.command = command;
        this.type = type;
        this.content = content;
    }
}
