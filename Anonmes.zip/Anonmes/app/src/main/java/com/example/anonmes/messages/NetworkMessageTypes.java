package com.example.anonmes.messages;

public enum NetworkMessageTypes {


    TYPE_LOGIN("0"),
    TYPE_HANDSHAKE("1"),
    TYPE_QUERY_MESSAGES("2"),
    TYPE_SEND_MESSAGE("3"),
    TYPE_REGISTER("4"),
    TYPE_QUERY_PUBKEY("5");



    private NetworkMessageTypes(String  number){
        this.number=number;
    }
    public String getVal(){
        return number;
    }

    String number;
}
