package com.example.anonmes;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.util.Log;

import com.example.anonmes.userdata.I2pDataSample;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class DataManager {
    public static void initialLoad(Activity activity) {
        SharedPreferences proxySettingPreferences = activity.getSharedPreferences("tunnel_settings", Context.MODE_PRIVATE);
        String val = proxySettingPreferences.getString("proxy", null);
        if (val == null) {
            proxySettingPreferences.edit().putString("proxy", "127.0.0.1").apply();
            proxySettingPreferences.edit().putString("port", "4272").apply();
            proxySettingPreferences.edit().putString("in", "3").apply();
            proxySettingPreferences.edit().putString("out", "3").apply();
            flushI2pSettings("127.0.0.1", "4272", "3", "3");
        } else {
            String port = proxySettingPreferences.getString("port", null);
            String in = proxySettingPreferences.getString("in", null);
            String out = proxySettingPreferences.getString("out", null);
            flushI2pSettings(val, port, in, out);
        }
    }

    public static void flushI2pSettings(String host, String port, String inbound_length, String outbound_length) {
        File file = new File(Environment.getExternalStorageDirectory().getPath() + "/i2pd/tunnels.conf");
        Log.i("CRYPT--", file.exists() + "");
        try {
            StringBuilder content = new StringBuilder();
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                content.append(scanner.nextLine());
                content.append('\n');
            }

            if (!content.toString().contains("[ANONMES-CONNECTION]")) {
                I2pDataSample sample = new I2pDataSample(host, port, inbound_length, outbound_length, "5hbx3367ivpo3rjaaylqvv7h2j45extvqedx5eqctordxvmshzlq.b32.i2p", "22341");
                FileWriter fileWriter = new FileWriter(file, true);
                fileWriter.append("\n");
                fileWriter.append(sample.getData());
                fileWriter.flush();
                fileWriter.close();
            } else {
                int ind = content.indexOf("[ANONMES-CONNECTION]");
                String cntn = content.substring(0, ind);
                I2pDataSample sample = new I2pDataSample(host, port, inbound_length, outbound_length, "5hbx3367ivpo3rjaaylqvv7h2j45extvqedx5eqctordxvmshzlq.b32.i2p", "22341");
                FileWriter fileWriter = new FileWriter(file, false);
                if (cntn.charAt(cntn.length() - 1) != '\n') {
                    cntn += '\n';
                }
                fileWriter.write(cntn + sample.getData());
                fileWriter.flush();
                fileWriter.close();
            }


            Log.i("CRYPT--", content.toString());
        } catch (FileNotFoundException e) {
            //throw new RuntimeException(e);
        } catch (IOException e) {
            //throw new RuntimeException(e);
        }
    }
}
