package com.example.anonmes.messages;

public class UserMessage {
    String content;
    String fromId;
    String toId;
    long time;
    String encryptedAes;

    public UserMessage(String content, String fromId, String toId) {
        this.content = content;
        this.fromId = fromId;
        this.toId = toId;
        time = System.currentTimeMillis();
    }

    public UserMessage(String content, String fromId, String toId, long time, String encryptedAes) {
        this.content = content;
        this.fromId = fromId;
        this.toId = toId;
        this.time = time;
        this.encryptedAes = encryptedAes;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFromId() {
        return fromId;
    }

    public void setFromId(String fromId) {
        this.fromId = fromId;
    }

    public String getToId() {
        return toId;
    }

    public void setToId(String toId) {
        this.toId = toId;
    }

    public long getTime() {
        return time;
    }

    public void setTime(long time) {
        this.time = time;
    }

    @Override
    public String toString() {
        return "UserMessage{" +
                "content='" + content + '\'' +
                ", fromId='" + fromId + '\'' +
                ", toId='" + toId + '\'' +
                ", time=" + time +
                '}';
    }

    public String getEncryptedAes() {
        return encryptedAes;
    }

    public void setEncryptedAes(String encryptedAes) {
        this.encryptedAes = encryptedAes;
    }
}
