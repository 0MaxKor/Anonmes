package com.example.anonmes.crypt;

import android.app.Activity;
import android.util.Base64;
import android.util.Log;

import com.example.anonmes.messages.NetworkMessage;
import com.example.anonmes.messages.NetworkMessageTypes;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.Key;
import java.util.Arrays;

public class ServerHandshake {
    String aes="";
    PrintWriter out;
    BufferedReader in;
    Activity act;

    public ServerHandshake(PrintWriter out, BufferedReader in,Activity act) {
        this.out = out;
        this.in = in;
        this.act = act;
    }
    public String getAes(){
        if (aes.isEmpty()){
            if (!handshake()){
                try {
                    Thread.sleep(10000);
                    handshake();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
        return aes;
    }
    public boolean handshake(){

        KeyLocalStorage keyLocalStorage = new KeyLocalStorage();
        String pub = keyLocalStorage.getPublicKey(act);
        NetworkMessage networkMessage = new NetworkMessage(NetworkMessageTypes.TYPE_HANDSHAKE.getVal(), 0,0,pub,1,1,"");
        Gson gson = new Gson();
        String s = gson.toJson(networkMessage);
        Log.i("AESSSSS","gsoned");
        out.println(s);
        out.flush();
        try {
            Log.i("AESSSSS","wait reply");
            String reply = in.readLine();
            NetworkMessage networkMessage1 = gson.fromJson(reply, NetworkMessage.class);
            byte[]aesCrypted = Base64.decode(networkMessage1.getContent(),Base64.NO_WRAP);

            MessageCrypt aesCrypt = new MessageCrypt(keyLocalStorage,act);
            byte[] aesnorm = aesCrypt.decryptDataRSA(aesCrypted);
            Log.i("AESSSSSSSS", new String(aesnorm));
            aes= new String(aesnorm);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }



        return true;
    }
}
