package com.example.anonmes.crypt;

import android.app.Activity;
import android.util.Base64;

import com.example.anonmes.Message;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class MessageCrypt {
    PrivateKey privateKey;
    Cipher cipher;

    public static PrivateKey getPrivateKeyFromString(String keyStr) throws Exception {
        byte[] clear = Base64.decode(keyStr, Base64.NO_WRAP);
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(clear);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePrivate(keySpec);
    }

    // Получаем PublicKey из строки
    public static PublicKey getPublicKeyFromString(String keyStr) throws Exception {
        byte[] clear = Base64.decode(keyStr, Base64.NO_WRAP);
        X509EncodedKeySpec keySpec = new X509EncodedKeySpec(clear);
        KeyFactory kf = KeyFactory.getInstance("RSA");
        return kf.generatePublic(keySpec);
    }

    public MessageCrypt(KeyLocalStorage keyLocalStorage, Activity anyActivity){


        String pvkey = keyLocalStorage.getPrivateKey(anyActivity);
        try {
            privateKey = getPrivateKeyFromString(pvkey);
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        }

    }
    public byte[] decryptDataRSA(byte[] data){
        try {
            return cipher.doFinal(data);
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        }
        return null;
    }
    public byte[] decryptDataAES(byte[] data, String key,byte[] iv)throws Exception{

            // 1. Декодируем общую строку и ключ
            byte[] decodedKey = Base64.decode(key, Base64.NO_WRAP);
            SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");

            // 2. Вырезаем IV (первые 12 байт для GCM)

            System.arraycopy(data, 0, iv, 0, iv.length);

            // 3. Вырезаем само зашифрованное сообщение
            int encryptedSize = data.length - iv.length;
            byte[] encryptedBytes = new byte[encryptedSize];
            System.arraycopy(data, iv.length, encryptedBytes, 0, encryptedSize);

            // 4. Настраиваем Cipher с использованием IV
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            GCMParameterSpec spec = new GCMParameterSpec(128, iv); // 128 - длина тега аутентификации
            cipher.init(Cipher.DECRYPT_MODE, originalKey, spec);

            // 5. Расшифровываем
        return cipher.doFinal(encryptedBytes);

    }
    public byte[] encryptDataAES(byte[] data, String key,byte[]iv) {
        // 1. Готовим ключ
        byte[] decodedKey = Base64.decode(key, Base64.NO_WRAP);
        SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");

        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");

            // 2. Генерируем случайный IV (12 байт для GCM)

            GCMParameterSpec spec = new GCMParameterSpec(128, iv);

            // 3. Инициализируем шифр с этим IV
            cipher.init(Cipher.ENCRYPT_MODE, originalKey, spec);
            byte[] encryptedData = cipher.doFinal(data);


            ByteBuffer byteBuffer = ByteBuffer.allocate(iv.length+ encryptedData.length);
            byteBuffer.put(iv);
            byteBuffer.put(encryptedData);

            return byteBuffer.array(); // Возвращаем всё вместе

        } catch (Exception e) {
            // В продакшене лучше логировать ошибку или выбрасывать свой Exception
            e.printStackTrace();
        }
        return null;
    }
    public String generateAESKey() {
        try {
            // 1. Создаем генератор именно для AES
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");

            // 2. Указываем длину ключа (256 бит — золотой стандарт)
            keyGen.init(256);

            // 3. Генерируем сам ключ
            SecretKey secretKey = keyGen.generateKey();

            // 4. Превращаем его в строку для передачи или временного хранения
            return Base64.encodeToString(secretKey.getEncoded(), Base64.NO_WRAP);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
    public byte[] encryptDataRSA(byte[] data, PublicKey publicKey){
        try {
            Cipher cipher1 = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            cipher1.init(Cipher.ENCRYPT_MODE,publicKey);
            return cipher1.doFinal(data);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (NoSuchPaddingException e) {
            e.printStackTrace();
        } catch (IllegalBlockSizeException e) {
            e.printStackTrace();
        } catch (BadPaddingException e) {
            e.printStackTrace();
        } catch (InvalidKeyException e) {
            e.printStackTrace();
        }
        return null;
    }
}
