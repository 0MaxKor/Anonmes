package com.example.anonmes.userdata;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.anonmes.messages.UserDeviceMessage;

import java.util.List;

@Dao
public interface UserDataDao {
    @Insert
    void insert(UserData userData);
    @Update
    void update(UserData userData);
    @Query("SELECT * FROM users")
    LiveData<List<UserData>> getAllUserdata();
    @Query("SELECT EXISTS(SELECT * FROM users WHERE uniqueName = :userName)")
    boolean isUserExists(String userName);
    @Query("SELECT pubKey FROM users WHERE uniqueName = :username")
    String getPubkeyForUser(String username);
    @Query("UPDATE users SET pubKey = :newKey WHERE uniqueName = :userName")
    void updateKeyByName(String userName, String newKey);

}
