package com.example.anonmes;

public enum Statuses {
    ERR_INVALID_LOGIN_DATA(-24),
    ERR_REGISTER_ERROR(-25),
    STATUS_REGISTER_SUCCESS(2),
    ERR_USER_WITH_SUCH_NAME_EXISTS(-67),
    ERR_NO_SUCH_USER(-23);
    int code;
    private Statuses(int c){
        code = c;
    }
    public int getCode(){
        return code;
    }
}
