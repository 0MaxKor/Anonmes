package com.example.anonmes;

import java.io.*;
import java.net.Socket;

public class SocketManager {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private Thread receiveThread;
    private OnMessageReceivedListener listener;

    public interface OnMessageReceivedListener {
        void onMessage(String text);
    }

    public void connect(String host, int port, OnMessageReceivedListener listener) {
        this.listener = listener;
        new Thread(() -> {
            try {
                socket = new Socket(host, port);
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));


                startReceiving();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void startReceiving() {
        receiveThread = new Thread(() -> {
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    if (listener != null) listener.onMessage(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        receiveThread.start();
    }

    public void sendMessage(String text) {
        new Thread(() -> {
            if (out != null) {
                out.println(text);
            }
        }).start();
    }
}
