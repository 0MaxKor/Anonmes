package com.example.anonmes;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.anonmes.crypt.KeyLocalStorage;
import com.example.anonmes.crypt.MessageCrypt;
import com.example.anonmes.crypt.ServerHandshake;
import com.example.anonmes.messages.LogRegMessage;
import com.example.anonmes.messages.MyDataLocal;
import com.example.anonmes.messages.NetworkMessage;
import com.example.anonmes.messages.NetworkMessageTypes;
import com.example.anonmes.messages.UserMessage;
import com.example.anonmes.userdata.EntryActivity;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class LoginActivity extends AppCompatActivity {
    EditText et_login;
    EditText et_passwd;
    EditText et_nick;
    CheckBox cb_rememberMe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.ac_login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        et_login = findViewById(R.id.et_login);
        et_nick = findViewById(R.id.et_username);
        et_passwd = findViewById(R.id.et_password);
        cb_rememberMe = findViewById(R.id.cb_remember);
    }

    public void clickLogin(View v) {
        String et_login_text = String.valueOf(et_login.getText());
        String et_passwd_text = String.valueOf(et_passwd.getText());
        String et_nick_text = String.valueOf(et_nick.getText());
        if (et_login_text.isEmpty() || et_nick_text.isEmpty() || et_passwd_text.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }
        if (et_nick_text.charAt(0) != '@') {
            Toast.makeText(this, "Введите ник в соответствии с форматом", Toast.LENGTH_SHORT).show();
        }

//        Intent intent = new Intent(this, EntryActivity.class);
//        startActivity(intent);


        SharedPreferences proxySettingPreferences = this.getSharedPreferences("tunnel_settings", Context.MODE_PRIVATE);
        String proxy = proxySettingPreferences.getString("proxy", null);
        String port = proxySettingPreferences.getString("port", null);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // 2. Весь сетевой код переносим сюда (строка 59 и далее)
                    // Пример:
                    Socket socket=null;
                    try {
                        socket = new Socket(proxy, Integer.parseInt(port));
                        socket.setSoTimeout(20000);
                        PrintWriter printWriter = new PrintWriter(socket.getOutputStream());

                        ServerHandshake handshake = new ServerHandshake(printWriter, new BufferedReader(new InputStreamReader(socket.getInputStream())), LoginActivity.this);
                        Log.i("AESSSSSSS", "before shake");
                        Log.i("AESSSSSSS", handshake.handshake() + "");

                        KeyLocalStorage keyLocalStorage = new KeyLocalStorage();
                        Log.i("AESSSSSSS", "after shake 1");
                        MessageCrypt messageCrypt = new MessageCrypt(keyLocalStorage, LoginActivity.this);
//                        Gson gson = new Gson();
//                        UserMessage userMessage = new UserMessage("Fuck sent","120910291","1228398",System.currentTimeMillis());
//                        String aessedUserMes = Base64.encodeToString(messageCrypt.encryptDataAES(gson.toJson(userMessage).getBytes(), handshake.getAes(), Constants.INITIAL_IV.getVal()),Base64.NO_WRAP);
//                        NetworkMessage sendmesNetw = new NetworkMessage(NetworkMessageTypes.TYPE_SEND_MESSAGE.getVal(), 0,0,aessedUserMes,0,0,"");
//                        String textToSen = gson.toJson(sendmesNetw);
//                        Log.i("AESSSSSS","Sending mes");
//                        printWriter.println(textToSen);
//                        printWriter.flush();
//                        Log.i("AESSSSSS","Sent mes");
//                        String reply = new BufferedReader(new InputStreamReader(socket.getInputStream())).readLine();
//                        Log.i("AESSSSSS","Reply: "+reply);
                        Log.i("AESSSSSSS", "after shake 2");
                        LogRegMessage logRegMessage = new LogRegMessage(et_nick_text, "", et_passwd_text);
                        Log.i("AESSSSSSS", "after shake 3");
                        Gson gson = new Gson();
                        String gsonedLogReg = gson.toJson(logRegMessage);
                        Log.i("AESSSSSSS", "after shake 4");
                        byte[] encryptedLogReg = null;
                        try {
                            Log.i("AESSSSSSS", "Starting encryption...");
                            Log.i("AESSSSSSS", "Starting encryption...");
                            String aes = handshake.getAes();
                            Log.i("AESSSSSSS", "AES: " + aes);
                            encryptedLogReg = messageCrypt.encryptDataAES(gsonedLogReg.getBytes(), aes, Constants.INITIAL_IV.getVal());
                            Log.i("AESSSSSSS", "after shake 5");
                        } catch (Exception e) {
                            Log.e("AESSSSSSS", "Encryption failed!", e); // Это покажет точную причину в логах
                        }
                        Log.i("AESSSSSSS", "after shake 5");
                        NetworkMessage networkMessage = new NetworkMessage(NetworkMessageTypes.TYPE_LOGIN.getVal(), 0, 0, Base64.encodeToString(encryptedLogReg, Base64.NO_WRAP), 0, 0, "");
                        Log.i("AESSSSSSS", "Seding logdata");

                        String json = gson.toJson(networkMessage);
//
                        printWriter.println(json);
                        printWriter.flush();
                        Log.i("AESSSSSSS", "Sent logdara, waitResp");

                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String loginResp = new String(messageCrypt.decryptDataAES(Base64.decode(bufferedReader.readLine(), Base64.NO_WRAP), handshake.getAes(), Constants.INITIAL_IV.getVal()));
                        boolean flagLoginSuccess = false;
                        try {
                            int r = Integer.parseInt(loginResp);
                            if (r > 0) {
                                flagLoginSuccess = true;
                                //Toast.makeText(LoginActivity.this, "Ошибка входа", Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                            //Toast.makeText(LoginActivity.this, "Ошибка входа", Toast.LENGTH_SHORT).show();
                        }
                        final boolean ff = flagLoginSuccess;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (ff) {
                                    Toast.makeText(LoginActivity.this, "Успешный вход", Toast.LENGTH_SHORT).show();
                                    MyDataLocal local = new MyDataLocal(logRegMessage.getName(),logRegMessage.getNick(),logRegMessage.getSha256Passwd(),LoginActivity.this);

                                    Intent intent = new Intent(LoginActivity.this, EntryActivity.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(LoginActivity.this, "Ошибка входа", Toast.LENGTH_SHORT).show();
                                }

                                Toast.makeText(LoginActivity.this, "Подключено!", Toast.LENGTH_SHORT).show();
                            }
                        });
                        socket.close();


                    } catch (SocketTimeoutException e) {
                        System.out.println("Таймаут! Данных нет. Закрываем соединение...");
                        socket.close(); // Закрываем вручную
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    // 3. Если нужно что-то показать на экране после подключения:


                } catch (Exception e) {
                    e.printStackTrace();
                    // Обработка ошибки (например, сервер выключен)
                }
            }
        }).start();


    }

    public void clickRegister(View v) {
        String et_login_text = String.valueOf(et_login.getText());
        String et_passwd_text = String.valueOf(et_passwd.getText());
        String et_nick_text = String.valueOf(et_nick.getText());
        if (et_login_text.isEmpty() || et_nick_text.isEmpty() || et_passwd_text.isEmpty()) {
            Toast.makeText(this, "Заполните все поля", Toast.LENGTH_SHORT).show();
            return;
        }
        if (et_nick_text.charAt(0) != '@') {
            Toast.makeText(this, "Введите ник в соответствии с форматом", Toast.LENGTH_SHORT).show();
        }
        SharedPreferences proxySettingPreferences = this.getSharedPreferences("tunnel_settings", Context.MODE_PRIVATE);
        String proxy = proxySettingPreferences.getString("proxy", null);
        String port = proxySettingPreferences.getString("port", null);

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    // 2. Весь сетевой код переносим сюда (строка 59 и далее)
                    // Пример:
                    Socket socket = null;
                    try {
                        socket = new Socket(proxy, Integer.parseInt(port));
                        socket.setSoTimeout(20000);
                        PrintWriter printWriter = new PrintWriter(socket.getOutputStream());

                        ServerHandshake handshake = new ServerHandshake(printWriter, new BufferedReader(new InputStreamReader(socket.getInputStream())), LoginActivity.this);
                        Log.i("AESSSSSSS", "before shake");
                        Log.i("AESSSSSSS", handshake.handshake() + "");

                        KeyLocalStorage keyLocalStorage = new KeyLocalStorage();
                        Log.i("AESSSSSSS", "after shake 1");
                        MessageCrypt messageCrypt = new MessageCrypt(keyLocalStorage, LoginActivity.this);
//                        Gson gson = new Gson();
//                        UserMessage userMessage = new UserMessage("Fuck sent","120910291","1228398",System.currentTimeMillis());
//                        String aessedUserMes = Base64.encodeToString(messageCrypt.encryptDataAES(gson.toJson(userMessage).getBytes(), handshake.getAes(), Constants.INITIAL_IV.getVal()),Base64.NO_WRAP);
//                        NetworkMessage sendmesNetw = new NetworkMessage(NetworkMessageTypes.TYPE_SEND_MESSAGE.getVal(), 0,0,aessedUserMes,0,0,"");
//                        String textToSen = gson.toJson(sendmesNetw);
//                        Log.i("AESSSSSS","Sending mes");
//                        printWriter.println(textToSen);
//                        printWriter.flush();
//                        Log.i("AESSSSSS","Sent mes");
//                        String reply = new BufferedReader(new InputStreamReader(socket.getInputStream())).readLine();
//                        Log.i("AESSSSSS","Reply: "+reply);
                        Log.i("AESSSSSSS", "after shake 2");
                        LogRegMessage logRegMessage = new LogRegMessage(et_nick_text, et_login_text, et_passwd_text);
                        Log.i("AESSSSSSS", "after shake 3");
                        Gson gson = new Gson();
                        String gsonedLogReg = gson.toJson(logRegMessage);
                        Log.i("AESSSSSSS", "after shake 4");
                        byte[] encryptedLogReg = null;
                        try {
                            Log.i("AESSSSSSS", "Starting encryption...");
                            Log.i("AESSSSSSS", "Starting encryption...");
                            String aes = handshake.getAes();
                            Log.i("AESSSSSSS", "AES: " + aes);
                            encryptedLogReg = messageCrypt.encryptDataAES(gsonedLogReg.getBytes(), aes, Constants.INITIAL_IV.getVal());
                            Log.i("AESSSSSSS", "after shake 5");
                        } catch (Exception e) {
                            Log.e("AESSSSSSS", "Encryption failed!", e); // Это покажет точную причину в логах
                        }
                        Log.i("AESSSSSSS", "after shake 5");
                        NetworkMessage networkMessage = new NetworkMessage(NetworkMessageTypes.TYPE_REGISTER.getVal(), 0, 0, Base64.encodeToString(encryptedLogReg, Base64.NO_WRAP), 0, 0, keyLocalStorage.getPublicKey(LoginActivity.this));
                        Log.i("AESSSSSSS", "Seding regdata");

                        String json = gson.toJson(networkMessage);
//
                        printWriter.println(json);
                        printWriter.flush();
                        Log.i("AESSSSSSS", "Sent regdara, waitResp");

                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String loginResp = new String(messageCrypt.decryptDataAES(Base64.decode(bufferedReader.readLine(), Base64.NO_WRAP), handshake.getAes(), Constants.INITIAL_IV.getVal()));
                        boolean flagLoginSuccess = false;
                        try {
                            int r = Integer.parseInt(loginResp);
                            if (r > 0) {
                                flagLoginSuccess = true;
                                //Toast.makeText(LoginActivity.this, "Ошибка входа", Toast.LENGTH_SHORT).show();
                            }
                        } catch (Exception e) {
                            //Toast.makeText(LoginActivity.this, "Ошибка входа", Toast.LENGTH_SHORT).show();
                        }
                        final boolean ff = flagLoginSuccess;
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (ff) {
                                    Toast.makeText(LoginActivity.this, "Успешная регистрация", Toast.LENGTH_SHORT).show();
                                    MyDataLocal local = new MyDataLocal(logRegMessage.getName(),logRegMessage.getNick(),logRegMessage.getSha256Passwd(),LoginActivity.this);

                                    Intent intent = new Intent(LoginActivity.this, EntryActivity.class);
                                    startActivity(intent);
                                } else {
                                    Toast.makeText(LoginActivity.this, "Ошибка регистрации", Toast.LENGTH_SHORT).show();
                                }

                                Toast.makeText(LoginActivity.this, "Подключено!", Toast.LENGTH_SHORT).show();
                            }
                        });
                        socket.close();


                    }catch (SocketTimeoutException e) {
                        socket.close(); // Закрываем вручную
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    // 3. Если нужно что-то показать на экране после подключения:


                } catch (Exception e) {
                    e.printStackTrace();
                    // Обработка ошибки (например, сервер выключен)
                }
            }
        }).start();
    }
}
