package com.example.anonmes.messages;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

public class MyDataLocal {
    String fullname="";
    String username="";
    String passwdHash="";
    Activity curr;
    public MyDataLocal(String fullname, String username, String passwdHash,Activity curr) {
        this.curr = curr;
        save(fullname,username,passwdHash);

    }
    public MyDataLocal(Activity activity) {
        curr = activity;
        SharedPreferences preferences = curr.getSharedPreferences("user_data_local", Context.MODE_PRIVATE);
        if (preferences.getString("fullname",null)!=null){
            fullname = preferences.getString("fullname",null);
            username = preferences.getString("username",null);
            passwdHash = preferences.getString("passwdHash",null);
        }


    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswdHash() {
        return passwdHash;
    }

    public void setPasswdHash(String passwdHash) {
        this.passwdHash = passwdHash;
    }
    public void save(String fullname,String username,String passwdHash){
        this.fullname=fullname;
        this.username=username;
        this.passwdHash = passwdHash;
        SharedPreferences preferences = curr.getSharedPreferences("user_data_local", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

// 3. Добавляем или обновляем значения
        editor.putString("fullname", fullname);
        editor.putString("username", username);
        editor.putString("passwdHash", passwdHash);
        editor.apply();
    }
}
