package com.example.anonmes;
import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MessageStorage {
    private static final String PREFS_NAME = "chat_prefs";
    private static final String KEY_MESSAGES = "messages_list";
    private SharedPreferences prefs;
    private Gson gson;

    public MessageStorage(Context context) {
        this.prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        this.gson = new Gson();
    }


    public void saveMessages(List<MessageModel> list,String chatId) {
        String json = gson.toJson(list);
        prefs.edit().putString(KEY_MESSAGES+chatId, json).apply();
    }


    public List<MessageModel> loadMessages(String chatId) {
        String json = prefs.getString(KEY_MESSAGES+chatId, null);
        if (json == null) return new ArrayList<>();


        Type type = new TypeToken<List<MessageModel>>() {}.getType();
        return gson.fromJson(json, type);
    }
}
