package com.example.anonmes.room;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import android.content.Context;

import com.example.anonmes.messages.MessageDao;
import com.example.anonmes.messages.UserDeviceMessage;
import com.example.anonmes.userdata.UserData;
import com.example.anonmes.userdata.UserDataDao;

@Database(entities = {UserData.class, UserDeviceMessage.class}, version = 1)
public abstract class AppDatabase extends RoomDatabase {
    public abstract UserDataDao userDao();
    public abstract MessageDao messageDao();

    private static AppDatabase instance;

    public static synchronized AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(context.getApplicationContext(),
                            AppDatabase.class, "anonmes_db")
                    .fallbackToDestructiveMigration() // Удалит данные при смене версии (для разработки ок)
                    .build();
        }
        return instance;
    }
}