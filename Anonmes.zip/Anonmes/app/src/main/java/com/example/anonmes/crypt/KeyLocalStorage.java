package com.example.anonmes.crypt;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import com.example.anonmes.MainActivity;

import java.security.InvalidAlgorithmParameterException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.spec.ECGenParameterSpec;

public class KeyLocalStorage {
    public String getPrivateKey(Activity activity){


        var prefs = activity.getSharedPreferences("user_keys", Context.MODE_PRIVATE);
        String privateKey = prefs.getString("priv_key","no");
        if (privateKey.equals("no")){

            SharedPreferences.Editor editor = prefs.edit();
            String[]keypair = generateKeyPair();
            editor.putString("priv_key",keypair[0]);
            editor.putString("pub_key",keypair[1]);
            editor.apply();
            return keypair[0];
        }else {
            return privateKey;
        }

    }
    public String getPublicKey(Activity activity){

        var prefs = activity.getSharedPreferences("user_keys", Context.MODE_PRIVATE);
        String publicKey = prefs.getString("pub_key","no");
        if (publicKey.equals("no")){

            SharedPreferences.Editor editor = prefs.edit();
            String[]keypair = generateKeyPair();
            editor.putString("priv_key",keypair[0]);
            editor.putString("pub_key",keypair[1]);
            editor.apply();
            return keypair[1];
        }else {
            return publicKey;
        }

    }
    String[]generateKeyPair(){
        String[]res = new String[2];
        KeyPairGenerator kpg = null;
        try {
            kpg = KeyPairGenerator.getInstance("RSA");
            kpg.initialize(2048);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

        try {
            KeyPair keyPair = kpg.generateKeyPair();
            res[0]= Base64.encodeToString(keyPair.getPrivate().getEncoded(),Base64.NO_WRAP);
            res[1]=Base64.encodeToString(keyPair.getPublic().getEncoded(),Base64.NO_WRAP);
        }catch (Exception e){
            e.printStackTrace();
        }


        return res;
    }
}
