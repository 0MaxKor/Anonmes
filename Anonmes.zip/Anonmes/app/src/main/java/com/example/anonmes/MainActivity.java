package com.example.anonmes;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.util.Log;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.anonmes.crypt.KeyLocalStorage;
import com.example.anonmes.crypt.MessageCrypt;

import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;

import kotlin.random.FallbackThreadLocalRandom;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });




        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
            }
        }



        KeyLocalStorage keyLocalStorage = new KeyLocalStorage();
        DataManager.initialLoad(this);
        MessageCrypt messageCrypt = new MessageCrypt(keyLocalStorage,this);





//            Log.i("CRYPT--","AES clear: "+aesKey);
//            Log.i("CRYPT--","Message: "+ new String(rascryptedMes));
//            Log.i("CRYPT--","Message: "+ Environment.getExternalStorageDirectory().getPath());
//        } catch (Exception e) {
//            throw new RuntimeException(e);
//        }



    }


    String[]generateKeyPair(){
        String[]res = new String[2];
        KeyPairGenerator kpg = null;
        try {
            kpg = KeyPairGenerator.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }

        KeyPair keyPair = kpg.generateKeyPair();
        res[0]=Base64.encodeToString(keyPair.getPrivate().getEncoded(),Base64.DEFAULT);
        res[1]=Base64.encodeToString(keyPair.getPublic().getEncoded(),Base64.DEFAULT);
        return res;
    }

    void upgradeKeyPair(){
        var prefs = getSharedPreferences("user_keys", Context.MODE_PRIVATE);

            SharedPreferences.Editor editor = prefs.edit();
            String[]keypair = generateKeyPair();
            editor.putString("priv_key",keypair[0]);
            editor.putString("pub_key",keypair[1]);
            editor.apply();

    }

    String getPrivateKey(){

            var prefs = getSharedPreferences("user_keys", Context.MODE_PRIVATE);
            String privateKey = prefs.getString("priv_key","no");
            if (privateKey.equals("no")){

                SharedPreferences.Editor editor = prefs.edit();
                String[]keypair = generateKeyPair();
                editor.putString("priv_key",keypair[0]);
                editor.putString("pub_key",keypair[1]);
                editor.apply();
                return keypair[0];
            }else {
                return privateKey;
            }

    }
    String getPublicKey(){

        var prefs = getSharedPreferences("user_keys", Context.MODE_PRIVATE);
        String publicKey = prefs.getString("pub_key","no");
        if (publicKey.equals("no")){

            SharedPreferences.Editor editor = prefs.edit();
            String[]keypair = generateKeyPair();
            editor.putString("priv_key",keypair[0]);
            editor.putString("pub_key",keypair[1]);
            editor.apply();
            return keypair[1];
        }else {
            return publicKey;
        }

    }
    public void clickTunnelSettings(View view){
        Intent intent = new Intent(MainActivity.this, TunnelSettingsActivity.class);
        startActivity(intent);
    }
    public void clickGoToLogin(View view){
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
    }
    public void clickGoToChats(View view){
        Intent intent = new Intent(MainActivity.this, ChatActivity.class);
        startActivity(intent);
    }
}