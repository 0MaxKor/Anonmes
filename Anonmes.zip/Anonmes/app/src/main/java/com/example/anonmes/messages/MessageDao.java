package com.example.anonmes.messages;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.anonmes.userdata.UserData;

import java.util.List;

@Dao
public interface MessageDao {
    @Insert
    void insert(UserDeviceMessage message);

    @Query("SELECT * FROM messages ORDER BY timestamp, userName ASC")
    LiveData<List<UserDeviceMessage>> getAllMessages();
    @Query("SELECT * FROM messages ORDER BY timestamp, userName ASC")
    List<UserDeviceMessage> getAllMessageSync();
    @Query("SELECT * FROM messages  WHERE username = :userName ORDER BY timestamp, userName ASC")
    LiveData<List<UserDeviceMessage>> getMessagesForUser(String userName);
}
