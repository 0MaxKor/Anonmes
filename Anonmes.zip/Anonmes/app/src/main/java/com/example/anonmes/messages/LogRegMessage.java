package com.example.anonmes.messages;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class LogRegMessage {
    String sha256Passwd;
    String nick;
    String name;

    public LogRegMessage(String nick, String name,String passwd) {
        this.nick = nick;
        this.name = name;
        try {
            sha256Passwd = getSHA256Hash(passwd);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public String getSHA256Hash(String text) throws Exception {
        // 1. Создаем экземпляр алгоритма SHA-256
        MessageDigest digest = MessageDigest.getInstance("SHA-256");

        // 2. Хешируем байты строки
        byte[] hashBytes = digest.digest(text.getBytes(StandardCharsets.UTF_8));

        // 3. Преобразуем байты в читаемый вид (Hex или Base64)
        // Вариант в Hex (шестнадцатеричный):
        StringBuilder hexString = new StringBuilder();
        for (byte b : hashBytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

    public String getSha256Passwd() {
        return sha256Passwd;
    }

    public void setSha256Passwd(String sha256Passwd) {
        this.sha256Passwd = sha256Passwd;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
