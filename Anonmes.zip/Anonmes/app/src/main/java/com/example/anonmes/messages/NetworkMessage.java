package com.example.anonmes.messages;

public class NetworkMessage {
    String type;
    int senderId;
    int destinationId;
    String content;
    int fragmentNum;
    int fragmentsTotal;
    String rsaKeyEncrypted;

    public NetworkMessage(String type, int senderId, int destinationId, String content,
                          int fragmentNum, int fragmentsTotal, String rsaKeyEncrypted) {
        this.type = type;
        this.senderId = senderId;
        this.destinationId = destinationId;
        this.content = content;
        this.fragmentNum = fragmentNum;
        this.fragmentsTotal = fragmentsTotal;
        this.rsaKeyEncrypted = rsaKeyEncrypted;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSenderId() {
        return senderId;
    }

    public void setSenderId(int senderId) {
        this.senderId = senderId;
    }

    public int getDestinationId() {
        return destinationId;
    }

    public void setDestinationId(int destinationId) {
        this.destinationId = destinationId;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getFragmentNum() {
        return fragmentNum;
    }

    public void setFragmentNum(int fragmentNum) {
        this.fragmentNum = fragmentNum;
    }

    public int getFragmentsTotal() {
        return fragmentsTotal;
    }

    public void setFragmentsTotal(int fragmentsTotal) {
        this.fragmentsTotal = fragmentsTotal;
    }

    public String getRsaKeyEncrypted() {
        return rsaKeyEncrypted;
    }

    public void setRsaKeyEncrypted(String rsaKeyEncrypted) {
        this.rsaKeyEncrypted = rsaKeyEncrypted;
    }
}
